﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using WebOdev.Models;

namespace WebOdev.Data
{
    public class ApplicationDbContext : IdentityDbContext<Admin>
    {
       

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
       public DbSet<Anasayfa>anasayfalar { get; set; }
        public DbSet<Oyunlar> oyunlars { get; set; }
        public DbSet<Yorumlar> yorumlars { get; set; }
        
    }
}
