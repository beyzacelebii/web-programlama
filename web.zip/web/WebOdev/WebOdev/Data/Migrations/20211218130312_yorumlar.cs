﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebOdev.Data.Migrations
{
    public partial class yorumlar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "OyunlarOyunID",
                table: "oyunlars",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OyunlarOyunID",
                table: "AspNetUsers",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "yorumlars",
                columns: table => new
                {
                    YorumID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    yorum = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AdminId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    OyunlarOyunID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_yorumlars", x => x.YorumID);
                    table.ForeignKey(
                        name: "FK_yorumlars_AspNetUsers_AdminId",
                        column: x => x.AdminId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_yorumlars_oyunlars_OyunlarOyunID",
                        column: x => x.OyunlarOyunID,
                        principalTable: "oyunlars",
                        principalColumn: "OyunID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_oyunlars_OyunlarOyunID",
                table: "oyunlars",
                column: "OyunlarOyunID");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_OyunlarOyunID",
                table: "AspNetUsers",
                column: "OyunlarOyunID");

            migrationBuilder.CreateIndex(
                name: "IX_yorumlars_AdminId",
                table: "yorumlars",
                column: "AdminId");

            migrationBuilder.CreateIndex(
                name: "IX_yorumlars_OyunlarOyunID",
                table: "yorumlars",
                column: "OyunlarOyunID");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_oyunlars_OyunlarOyunID",
                table: "AspNetUsers",
                column: "OyunlarOyunID",
                principalTable: "oyunlars",
                principalColumn: "OyunID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_oyunlars_oyunlars_OyunlarOyunID",
                table: "oyunlars",
                column: "OyunlarOyunID",
                principalTable: "oyunlars",
                principalColumn: "OyunID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_oyunlars_OyunlarOyunID",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_oyunlars_oyunlars_OyunlarOyunID",
                table: "oyunlars");

            migrationBuilder.DropTable(
                name: "yorumlars");

            migrationBuilder.DropIndex(
                name: "IX_oyunlars_OyunlarOyunID",
                table: "oyunlars");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_OyunlarOyunID",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "OyunlarOyunID",
                table: "oyunlars");

            migrationBuilder.DropColumn(
                name: "OyunlarOyunID",
                table: "AspNetUsers");
        }
    }
}
