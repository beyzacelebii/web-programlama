﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebOdev.Models
{
    public class OyunYorum
    {
        public IEnumerable<Oyunlar> OyunDeger { get; set; }
        public IEnumerable<Yorumlar> YorumDeger { get; set; }

    }
}
