﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebOdev.Models
{
    public class Oyunlar
    {
        [Key]
        public int OyunID { get; set; }
        public string Baslik { get; set; }
        public string Aciklama { get; set; }

        public string OyunImage { get; set; }
        public string OyunTuru { get; set; }
        public string OyunTarihce { get; set; }

        public ICollection<Admin> admins { get; set; }
        public ICollection<Oyunlar> oyunlarss { get; set; }

    }
}
