﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebOdev.Models
{
    public class Yorumlar
    {
        [Key]
        public int YorumID { get; set; }
        public string yorum { get; set; }

        public int Oyunid { get; set; }
        public virtual Oyunlar Oyunlar { get; set; }
         public Admin Admin { get; set; }
        
    }
}
