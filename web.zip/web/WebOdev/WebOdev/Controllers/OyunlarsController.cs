﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebOdev.Data;
using WebOdev.Models;

namespace WebOdev.Controllers
{
    public class OyunlarsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OyunlarsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Oyunlars
        public async Task<IActionResult> Index()
        {
            return View(await _context.oyunlars.ToListAsync());
        }

        // GET: Oyunlars/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyunlar = await _context.oyunlars
                .FirstOrDefaultAsync(m => m.OyunID == id);
            if (oyunlar == null)
            {
                return NotFound();
            }

            return View(oyunlar);
        }

        // GET: Oyunlars/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Oyunlars/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OyunID,Baslik,Aciklama,OyunImage,OyunTuru,OyunTarihce")] Oyunlar oyunlar)
        {
            if (ModelState.IsValid)
            {
                _context.Add(oyunlar);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(oyunlar);
        }

        // GET: Oyunlars/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyunlar = await _context.oyunlars.FindAsync(id);
            if (oyunlar == null)
            {
                return NotFound();
            }
            return View(oyunlar);
        }

        // POST: Oyunlars/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("OyunID,Baslik,Aciklama,OyunImage,OyunTuru,OyunTarihce")] Oyunlar oyunlar)
        {
            if (id != oyunlar.OyunID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(oyunlar);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OyunlarExists(oyunlar.OyunID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oyunlar);
        }

        // GET: Oyunlars/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyunlar = await _context.oyunlars
                .FirstOrDefaultAsync(m => m.OyunID == id);
            if (oyunlar == null)
            {
                return NotFound();
            }

            return View(oyunlar);
        }

        // POST: Oyunlars/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oyunlar = await _context.oyunlars.FindAsync(id);
            _context.oyunlars.Remove(oyunlar);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OyunlarExists(int id)
        {
            return _context.oyunlars.Any(e => e.OyunID == id);
        }
    }
}
