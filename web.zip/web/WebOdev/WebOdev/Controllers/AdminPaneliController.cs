﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebOdev.Data;
using WebOdev.Models;
namespace WebOdev.Controllers
{
    public class AdminPaneliController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminPaneliController(ApplicationDbContext context)
        {
            _context = context;
        }

      
        public IActionResult Index()
        {
            var degerler = _context.oyunlars.ToList();
            return View(degerler);
        }
    }
}
