﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Localization;
using Microsoft.Web.Services3.Security.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebOdev.Data;

namespace WebOdev.Controllers
{
    public class AnaSayfaController : Controller
    {
        private readonly IHtmlLocalizer<AnaSayfaController> _localizer;
        private readonly ApplicationDbContext _context;

        public DateTimeOffset Expires { get; private set; }

        public AnaSayfaController(ApplicationDbContext context,IHtmlLocalizer<AnaSayfaController> localizer)
        {
            _context = context;
            _localizer = localizer;
        }
        // anasayfayı listeliyor.
        public IActionResult Index()
        {
            var test = _localizer["x.Aciklama"];
           // ViewData["x.Aciklama"] = test;
            var degerler = _context.anasayfalar.ToList();
            return View(degerler);
        }
        [HttpPost]
        public IActionResult CultureManagement(string culture,string returnUrl)
        {
            Response.Cookies.Append(CookieRequestCultureProvider.DefaultCookieName, CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions { Expires = DateTimeOffset.Now.AddDays(30)});
            return LocalRedirect(returnUrl);
        }
    }
}
